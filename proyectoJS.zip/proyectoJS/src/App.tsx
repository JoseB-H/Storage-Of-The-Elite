import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import './App.css'
import AppLayout from './components/AppLayout'
import Dashboard from './components/Dashboard'
import CapitulosLayout from './Capitulos/CapitulosLayout'
import SeriesLayout from './Series/SeriesLayout'
import AuthLayout from './auth/AuthLayout'
import AuthForm from './auth/AuthForm'
import VerSeries from './Series/VerSerie'
import MainSeries from './Series/MainSeries'
import Capitulos from './Capitulos/Capitulos'
import CapituloDetalles from './Capitulos/CapituloDetalles'

const router = createBrowserRouter([
  {
    path: '/',
    element: <AppLayout></AppLayout>,
    children: [
      {
        path: '',
        element: <Dashboard></Dashboard>,
      }
    ]
  },
  {
    path: 'capitulos',
    element: <CapitulosLayout></CapitulosLayout>,
    children:[
      {
        path: '',
        element: <Capitulos></Capitulos>
      },
      {
        path: 'CapituloDetalles',
        element: <CapituloDetalles></CapituloDetalles>
      },
    ]
  },
  {
    path: 'series',
    element: <SeriesLayout></SeriesLayout>,
    children:[
      {
        path: '',
        element: <MainSeries></MainSeries>
      },
      {
        path: 'new',
        element: <VerSeries></VerSeries>
      }
    ]
  },
  {
    path: 'auth',
    element: <AuthLayout></AuthLayout>,
    children: [
      {
        path: '',
        element: <AuthForm></AuthForm>
      },
    ]
  }


])
  

function App() {

  return (
    <RouterProvider router={router} />
  )
}

export default App

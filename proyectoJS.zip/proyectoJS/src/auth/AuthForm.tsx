import { useState } from "react";
import { useForm } from "react-hook-form";
import type { FormData } from "../service/FormData";
import 'bootstrap-icons/font/bootstrap-icons.css';

function AuthForm() {
  const [isLogin, setIsLogin] = useState(true);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>();

  const onSubmit = (data: FormData) => {
    console.log("Datos enviados:", data);
  };

  return (
    <div className="container mt-5" style={{ maxWidth: "500px" }}><br></br><br></br>
      <h3 className="text-center mb-4 text-white">{isLogin ? "Iniciar sesión" : "Registrarse"}</h3>
      <form onSubmit={handleSubmit(onSubmit)}>
        {!isLogin && (
          <>
            <div className="form-outline mb-4">
              <input
                type="text"
                className={`form-control ${errors.firstName ? "is-invalid" : ""}`}
                {...register("firstName", { required: "El nombre es obligatorio" })}/>{errors.firstName && <p className="text-danger small">{errors.firstName.message}</p>}
              <label className="form-label text-white">Nombre</label>
            </div>

            <div className="form-outline mb-4">
              <input
                type="text"
                className={`form-control ${errors.lastName ? "is-invalid" : ""}`}
                {...register("lastName", { required: "El apellido es obligatorio" })}
              />
              <label className="form-label text-white">Apellido</label>
              {errors.lastName && <p className="text-danger small">{errors.lastName.message}</p>}
            </div>
          </>
        )}

        <div className="form-outline mb-4">
          <input
            type="email"
            className={`form-control ${errors.email ? "is-invalid" : ""}`}
            {...register("email", {
              required: "El correo es obligatorio",
              pattern: {
                value: /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
                message: "Correo inválido",
              },
            })}
          />
          <label className="form-label text-white">Correo electrónico</label>
          {errors.email && <p className="text-danger small">{errors.email.message}</p>}
        </div>

        <div className="form-outline mb-4">
          <input
            type="password"
            className={`form-control ${errors.password ? "is-invalid" : ""}`}
            {...register("password", {
              required: "La contraseña es obligatoria",
              minLength: {
                value: 6,
                message: "Debe tener al menos 6 caracteres",
              },
            })}
          />
          <label className="form-label text-white">Contraseña</label>
          {errors.password && <p className="text-danger small">{errors.password.message}</p>}
        </div>

        <button type="submit" className="btn btn-primary btn-block mb-3">
          {isLogin ? "Iniciar sesión" : "Registrarse"}
        </button>

        <div className="text-center text-white">
          <p>
            {isLogin ? "¿No tienes cuenta?" : "¿Ya tienes cuenta?"}{" "}
            <a href="#!" onClick={() => setIsLogin(!isLogin)}>
              {isLogin ? "Regístrate" : "Inicia sesión"}
            </a>
          </p>
          <p>O ingresa con:</p>
          <button type="button" className="btn btn-primary btn-floating mx-1"><i className="bi bi-facebook"></i></button>
          <button type="button" className="btn btn-light btn-floating mx-1"><i className="bi bi-google"></i></button>
          <button type="button" className="btn btn-secondary btn-floating mx-1"><i className="bi bi-twitter-x"></i></button>
          <button type="button" className="btn btn-dark btn-floating mx-1"><i className="bi bi-github"></i></button>
        </div>
      </form><br></br><br></br><br></br><br></br>
    </div>
  );
}

export default AuthForm;

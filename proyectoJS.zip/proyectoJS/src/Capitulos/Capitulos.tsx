import { useEffect, useState } from "react";
import type { SerieCapitulos } from "../service/SerieCapitulos";
import { Link } from "react-router-dom";
import img1 from '../IMG/Img-1.webp';

function Capitulos() {
  const [series, setSeries] = useState<SerieCapitulos[]>([]);
  const [visibleCount, setVisibleCount] = useState(10);

  useEffect(() => {
    fetch("http://localhost:3000/Capitulos")
      .then(res => res.json())
      .then(setSeries);
  }, []);

  const mostrarMas = () => {
    setVisibleCount((prev) => prev + 10);
  };

  return (
    <section className="py-5" style={{ backgroundColor: "#111827", minHeight: "100vh" }}>
      <br /><br />
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div className="container-fluid d-flex justify-content-center align-items-center">
          <Link to='/'><img src={img1} alt="Logo" width={30} className="mb-3" /></Link>
          <ul className="navbar-nav d-flex flex-row align-items-center">
            <li className="nav-item mx-2">
              <Link className="nav-link" to="/">Inicio</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="">Capitulos</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/capitulos/CapituloDetalles">CapituloDetalles</Link>
            </li>
          </ul>
        </div>
      </nav>

      <div className="container">
        <h2 className="text-white mb-4 fw-bold">Últimos capítulos</h2>
        <div className="row row-cols-1 row-cols-md-2 g-4 justify-content-center">
          {series.slice(0, visibleCount).map(serie => (
            <div key={serie.id} className="col-md-5">
              <div className="card bg-dark border-0 rounded shadow p-3 h-100">
                <div className="d-flex">
                  <img src={serie.imagen}alt={serie.titulo}width={100}height={100}className="rounded"style={{ objectFit: "cover", marginRight: "16px" }} />
                  <div className="d-flex flex-column justify-content-center flex-grow-1">
                    <div className="d-flex align-items-center mb-2">
                      <h5 className="mb-0 text-white flex-grow-1">{serie.titulo}</h5>
                      <span className={`badge ${serie.estado === 'Finalizado' ? 'bg-danger' : 'bg-success'}`}>
                        {serie.estado}
                      </span>
                    </div>
                    <ul className="list-unstyled mb-0">
                      {serie.capitulos.slice(0, 2).map((cap, idx) => (
                        <li key={idx} className="text-white">
                          <Link to='/' className="text-white text-decoration-none">
                            ● Capítulo {cap.numero}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        {visibleCount < series.length && (
          <div className="text-center mt-4">
            <button className="btn btn-primary" onClick={mostrarMas}>Mostrar más</button>
          </div>
        )} <br /><br />
      </div>
    </section>
  );
}

export default Capitulos;

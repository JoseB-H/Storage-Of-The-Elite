import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import 'bootstrap-icons/font/bootstrap-icons.css';
import type { Manhwa } from "../service/CapituloDetalles";

function CapituloDetalles() {
  const [manhwas, setManhwas] = useState<Manhwa[]>([]);

  useEffect(() => {
    fetch("http://localhost:3000/CapituloDetalles")
      .then((res) => res.json())
      .then((data) => setManhwas(data))
      .catch((err) => console.error("Error al cargar manhwas", err));
  }, []);

  if (manhwas.length === 0) {
    return <div className="text-white text-center py-5">Cargando manhwas...</div>;
  }

  return (
    <div className="container py-5 text-white"><br></br>
      <h2 className="mb-4 text-light text-center">Todos los Manhwas</h2>
      <div className="row">
        {manhwas.map((manhwa) => (
          <div key={manhwa.id} className="col-md-4 col-lg-3 mb-4">
            <div className="card bg-dark text-white h-100 shadow">
              <img src={manhwa.portada} className="card-img-top" alt={manhwa.titulo} />
              <div className="card-body d-flex flex-column">
                <h5 className="card-title">{manhwa.titulo}</h5>
                <p className="card-text small">{manhwa.sinopsis}</p>
                <p className="mb-1">👁 {manhwa.vistas.toLocaleString()}</p>
                <p>❤️ {manhwa.likes.toLocaleString()}</p>
                <Link to='/capitulos' className="btn btn-warning mt-auto text-dark fw-bold">Ver Capítulos →</Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default CapituloDetalles;

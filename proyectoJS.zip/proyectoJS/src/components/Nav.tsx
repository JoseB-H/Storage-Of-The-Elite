import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import img1 from '../IMG/Img-1.webp';
import user from '../IMG/user.png';

function Nav() {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (query.trim() !== "") {
      navigate(`/buscar?q=${encodeURIComponent(query)}`);
      setQuery(""); 
    }
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div className="container-fluid d-flex justify-content-center align-items-center">
        <Link to='/' className="me-3">
          <img src={img1} alt="Logo" width={30} className="mb-1" />
        </Link>

        <ul className="navbar-nav d-flex flex-row align-items-center">
          <li className="nav-item mx-2">
            <Link className="nav-link" to="/">Inicio</Link>
          </li>
          <li className="nav-item mx-2">
            <Link className="nav-link" to="/series">Series</Link>
          </li>
          <li className="nav-item mx-2">
            <Link className="nav-link" to="/capitulos">Capítulos</Link>
          </li>
        </ul>

        <form onSubmit={handleSearch} className="d-flex mx-3" role="search">
          <input
            type="search"
            className="form-control form-control-sm text-white bg-secondary border-0"
            placeholder="Buscar..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            style={{ width: "180px" }}
          />
        </form>

        <Link to='/auth' className="ms-3">
          <img src={user} alt="User" width={30} className="mb-1" />
        </Link>
      </div>
    </nav>
  );
}

export default Nav;

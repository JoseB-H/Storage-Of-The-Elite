import Hiatus from '../IMG/Hiatus.jpg';
import mercenario from '../IMG/mercenario.jpg';
import novato from '../IMG/novato.webp';
import solo from '../IMG/solo.jpg';
import supervivencia from '../IMG/supervivencia.webp';
import reencarnation from '../IMG/reencarnation.jpg';
import runcandel from '../IMG/runcandel.webp';
import Img2 from '../IMG/Img-2.webp';
import img3 from '../IMG/img-3.jfif';
import img4 from '../IMG/img-4.jfif';
import { Link } from 'react-router-dom';

function Dashboard() {
  const gridCards = [
    { img: Hiatus, title: "Hiatus" },
    { img: mercenario, title: "Mercenario adolescente" },
    { img: novato, title: "Novato al maximo Nivel" },
    { img: solo, title: "Solo Leveling" },
    { img: supervivencia, title: "Guia de la Supervivencia en la academia" },
    { img: reencarnation, title: "Reencarnación" },
    { img: runcandel, title: "El hijo menor del maestro de la espada" },
    { img: Img2, title: "Lector onniconciente" },
    { img: img3, title: "leviathan" },
    { img: img4, title: "La vida despues de la muerte" },
  ];

  return (
    <div className="container container-dark my-5"style={{marginTop: "80px", }}><br></br>
      <div className="row mb-4">
        <div className="col-lg-8 position-relative">
          <div className="img-overlay-container">
            <img src={Hiatus}alt="Grande"className="img-fluid rounded img-blur"style={{height: "500px",width: "100%",objectFit: "cover"}}/>
            <Link to="/series/new" className="overlay-text">Ver</Link>
          </div>
        </div>
        <div className="col-lg-4 d-flex flex-column justify-content-between">
          <div className="img-overlay-container mb-2" style={{ height: "245px" }}>
            <img src={mercenario}alt="Mediana 1"className="img-fluid rounded img-blur h-100 w-100"style={{ objectFit: "cover" }}/>
            <Link to="/series/new" className="overlay-text">Ver</Link>
          </div>
          <div className="img-overlay-container" style={{ height: "245px" }}>
            <img src={supervivencia}alt="Mediana 2"className="img-fluid rounded img-blur h-100 w-100"style={{ objectFit: "cover" }}/>
            <Link to="/series/new" className="overlay-text">Ver</Link>
          </div>
        </div>
      </div>

      <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-5 g-4">
        {gridCards.map((item, index) => (
          <div className="col" key={index}>
            <div className="card h-100 text-light border border-secondary" style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}>
              <img src={item.img}className="card-img-top"alt={item.title}style={{ height: "250px", objectFit: "cover" }}/>
              <div className="card-body">
                <h5 className="card-title text-center">{item.title}</h5>
              </div>
            </div>
          </div>
        ))}
      </div><br></br>
      <h1 className='text-none'><Link to='/series/new' className="btn btn-primary btn-lg fs-2">Ver mas</Link></h1>
    </div>
  );
}

export default Dashboard;

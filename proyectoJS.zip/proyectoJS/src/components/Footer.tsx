
function Footer() {
  return (
    <footer className="page-footer font-small bg-dark fixed-bottom">
      <div className="footer-copyright text-center py-3 text-light">
        © 2025 Copyright: Proyecto de JS ....
        <a href="https://utp.edu.pe"> Universidad Tecnológica del Perú</a>
      </div>
    </footer>
  );
}

export default Footer;

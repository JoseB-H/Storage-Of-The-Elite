import { useEffect, useState } from "react";
import type { Manhwa } from "../service/VerSerie";


function VerSeries() {
  const [manhwas, setManhwas] = useState<Manhwa[]>([]);

  useEffect(() => {
    const fetchManhwas = async () => {
      try {
        const response = await fetch("http://localhost:3000/manhwas");
        const data = await response.json();
        console.log("Datos manhwas:", data); 
        setManhwas(data);
      } catch (error) {
        console.error("Error al cargar los manhwas:", error);
      }
    };

    fetchManhwas();
  }, []);

  return (
    <div className="container mt-5 pt-5" style={{ marginTop: "auto" }}>
      <h2 className="text-white text-center mb-4">Recomendaciones</h2>
        <div className="d-flex flex-nowrap overflow-auto pb-3 gap-3">
        {manhwas.slice(0, 10).map((manhwa) => (
          <div key={manhwa.id}className="card bg-dark text-white flex-shrink-0"style={{ width: "160px" }}>
            <img src={manhwa.imagen}alt={manhwa.titulo}className="card-img-top"style={{height: "220px",objectFit: "cover",borderTopLeftRadius: "0.5rem",borderTopRightRadius: "0.5rem"}}/>
            <div className="card-body p-2 text-center">
              <h6 className="card-title mb-0 text-truncate"style={{ fontSize: "14px" }}>{manhwa.titulo}
              </h6>
            </div>
          </div>))}
      </div>
      <h2 className="text-white text-center mt-5 mb-4">Todas las Series</h2>
      <div className="row row-cols-2 row-cols-sm-2 row-cols-md-3 row-cols-lg-5 g-3">
        {manhwas.map((manhwa) => (
          <div className="col" key={manhwa.id}>
            <div className="card h-100 bg-dark text-white">
              <img src={manhwa.imagen}alt={manhwa.titulo}className="card-img-top"style={{ height: "250px", objectFit: "cover" }}/>
              <div className="card-body text-center">
                <h5 className="card-title text-truncate"style={{ fontSize: "16px", fontWeight: "500" }}>{manhwa.titulo}</h5>
              </div>
            </div>
          </div>
        ))}
      </div><br></br><br></br>
    </div>
  );
}

export default VerSeries;

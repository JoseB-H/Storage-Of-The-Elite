import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import img1 from '../IMG/Img-1.webp';
import type { Video } from "../service/MainSeries";

function MainSeries() {
  const [videos, setVideos] = useState<Video[]>([]);

  useEffect(() => {
    const fetchVideos = async () => {
      try {
        const response = await fetch("http://localhost:3000/videos");
        const data = await response.json();
        setVideos(data);
      } catch (error) {
        console.error("Error al cargar los videos:", error);
      }
    };

    fetchVideos();
  }, []);

  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div className="container-fluid d-flex justify-content-center align-items-center">
          <Link to='/'><img src={img1} alt="Logo" width={30} className="mb-3" /></Link>
          <ul className="navbar-nav d-flex flex-row align-items-center">
            <li className="nav-item mx-2">
              <Link className="nav-link" to="/">Inicio</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/series/new">Nuevas Series</Link>
            </li>
          </ul>
        </div>
      </nav>
      {/* SECCIÓN DE VIDEOS */}
      <div className="container mt-5 pt-5 text-white">
        <h2 className="text-center my-4">🎥 Manhwas que Tendrán Adaptación a Anime</h2>
        <div className="row g-4">
          {videos.map((video) => (
            <div className="col-md-6 col-lg-4" key={video.id}>
              <div className="card bg-dark text-white h-100 border-0 shadow">
                <iframe className="card-img-top"height="215"src={video.url}title={video.titulo}allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"allowFullScreen></iframe>
                <div className="card-body">
                  <h5 className="card-title">{video.titulo}</h5>
                  <p className="card-text">{video.descripcion}</p>
                </div>
              </div>
            </div>
          ))}
        </div><br></br><br></br>
      </div>
    </>
  );
}

export default MainSeries;

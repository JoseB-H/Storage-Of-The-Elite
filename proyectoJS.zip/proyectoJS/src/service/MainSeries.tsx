export interface Video {
  id: number;
  titulo: string;
  descripcion: string;
  url: string;
}
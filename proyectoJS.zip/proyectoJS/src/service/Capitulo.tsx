export interface Capitulo {
  id: any;
  numero: string;
}
import type { Capitulo } from "./Capitulo";

export interface SerieCapitulos {
  id: number;
  titulo: string;
  estado: string;
  imagen: string;
  capitulos: Capitulo[];
}
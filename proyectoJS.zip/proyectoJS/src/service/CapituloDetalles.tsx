export interface Manhwa {
  id: number;
  titulo: string;
  portada: string;
  sinopsis: string;
  vistas: number;
  likes: number;
}
export interface Manhwa {
  id: number;
  titulo: string;
  imagen: string;
}
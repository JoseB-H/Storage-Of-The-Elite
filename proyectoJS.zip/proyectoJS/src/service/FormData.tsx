export type FormData = {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
};